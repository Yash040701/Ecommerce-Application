package com.hexaware.main;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import com.hexaware.dao.*;
import com.hexaware.entity.*;
import com.hexaware.exception.CustomerNotFoundException;
import com.hexaware.exception.ProductNotFoundException;
import com.hexaware.extraMethods.*;
public class Ecommerce_App {
	
	public static void main(String[] args) throws SQLException, CustomerNotFoundException, ProductNotFoundException, ParseException {
		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		IOrderProcessorRepository opr=new OrderProcessorRepositoryImpl();
		
		 System.out.println("!!!! Welcome to our Ecommerce Application !!!!");
		 System.out.println("Please Select Operation of you Choice: ");
		 while (true) {
	            System.out.println("1. Register Customer");
	            System.out.println("2. Create Product.");
	            System.out.println("3. Delete Product");
	            System.out.println("4. Add to cart");
	            System.out.println("5. View cart.");
	            System.out.println("6. Place order.");
	            System.out.println("7. View Customer Order ");
	            System.out.println("8. Exit");
	            
	            int choice=sc.nextInt();
	            
	            switch (choice) {
	            
	            case 1:
	            	
	            	Customers c=new Customers();
	            	System.out.println("Enter Customer Id");
	            	int id=sc.nextInt();
	            	c.setCustomerId(id);
	            	sc.nextLine();
	            	System.out.println("Enter Customer Name");
	            	String name=sc.nextLine();
	            	c.setName(name);
	            	System.out.println("Enter Email");
	            	String email=sc.nextLine();
	            	c.setEmail(email);
	            	System.out.println("Enter Password");
	            	String pass=sc.nextLine();
	            	c.setPassword(pass);
	            	opr.createCustomer(c);
	            	break;
	            	
	            case 2:
	            	
	            	Products p=new Products();
	        		System.out.println("Enter Product ID: ");
	            	int pid=sc.nextInt();
	            	p.setProductId(pid);
	            	sc.nextLine();
	            	System.out.println("Enter Product name: ");
	            	String pname=sc.nextLine();
	            	p.setpName(pname);
	            	System.out.println("Enter Price: ");
	            	double price=sc.nextDouble();
	            	p.setPrice(price);
	            	sc.nextLine();
	            	System.out.println("Describe Product: ");
	            	String descr=sc.nextLine();
	            	p.setDescription(descr);
	            	System.out.println("Enter Quantity: ");
	            	int quant=sc.nextInt();
	            	p.setStockQuantity(quant);
	            	sc.nextLine();
	            	opr.createProduct(p);
	            	break;
	            	
	            case 3:
	            	System.out.println("Enter Prodcut id");
	            	int dpid=sc.nextInt();
	            	opr.deleteProduct(dpid);
	            	
	            	break;
	            	
	            case 4:
	            	
	            	Cart cart=new Cart();
	            	Products p1=new Products();
	            	Customers cus1=new Customers();
	            	System.out.println("Enter Cart ID: ");
	            	int cid=sc.nextInt();
	            	cart.setCartId(cid);
	            	System.out.println("Enter Customer ID: ");
	            	int ccid=sc.nextInt();
	            	cus1.setCustomerId(ccid);
	            	System.out.println("Enter Product ID: ");
	            	int cpid=sc.nextInt();
	            	p1.setProductId(cpid);
	            	System.out.println("Enter Quantity: ");
	            	int cquant=sc.nextInt();
	            	cart.setQuantity(cquant);
	            	
	            	opr.addToCart(cart, cus1, p1, cquant);
	            	break;
	            	
	            case 5:
	                System.out.println("Enter Customer ID");
	                int casID=sc.nextInt();
	                sc.nextLine();
	            	Customers cus2=new Customers();
	            	cus2.setCustomerId(casID);
	            	List<Products> cartProducts=opr.getAllFromCart(cus2);
	            	if(cartProducts.isEmpty()) {
	            		System.out.println("No Product Available");
	            	}
	            	else {
	            		for(Products pd:cartProducts) {
	            			System.out.println("Following are the products in Cart:");
	            			System.out.println(pd);
	            		}
	            	}
	            	break;
	            
	            case 6:
	   
	            	Orders o=new Orders();
	            	System.out.println("Enter shipping address: ");
	                String shippingAddress = sc.nextLine();
	                sc.nextLine();
	                o.setShippingAddress(shippingAddress);
	                Customers c2=new Customers();
	                c2.setCustomerId(9);
	                System.out.println("Enter Order ID");
	                int oid=sc.nextInt();
	                o.setOrderId(oid);
	                System.out.print("Enter a date (yyyy/MM/dd): ");  
	                String dateStr = sc.next();  
	                SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");  
	                Date date = sdf.parse(dateStr);
	                java.sql.Date sqlDate = new java.sql.Date(date.getTime()); 
	                o.setOrderDate(sqlDate);
	                System.out.println("Enter Total Price:");
	                double tp=sc.nextDouble();
	                sc.nextLine();
	                o.setTotalPrice(tp);
	                List<Products> cartProducts1 = opr.getAllFromCart(c2);;
	                boolean isDone=opr.placeOrder(c2,o, PandQ.getProductsAndQuantities(cartProducts1));
	                if (isDone) {
	                    System.out.println("Order placed successfully!");
	                } else {
	                    System.out.println("Failed to place the order. Please try again.");
	                }
	            case 7:
	            	
	            	System.out.println("Enter the customer id to view the customer's orders: ");
	            	int customerId = sc.nextInt();
	            	sc.nextLine();
	            	List<Map<Products, Integer>> ordersList = opr.getOrdersByCustomer(customerId);
	            	if (ordersList.isEmpty()) {
	            	    System.out.println("No orders found for the customer ID: " + customerId);
	            	} else {
	            	    System.out.println("Orders for customer ID " + customerId + ":");

	            	    for (Map<Products, Integer> orderDetails : ordersList) {
	            	        System.out.println("Order Details:");
	            	        for (Map.Entry<Products, Integer> entry : orderDetails.entrySet()) {
	            	            Products product1 = entry.getKey();
	            	            int quantity = entry.getValue();

	            	            System.out.println("Product: " + product1.getpName());
	            	            System.out.println("Quantity: " + quantity);
	            	            // Print other product details as needed
	            	        }
	            	        
	            	    }
	            	}
	        	
	            	
	            	
	            	
	            case 8:
                    System.out.println("Exiting the Order Management System. Goodbye!");
                    System.exit(0);
                    break;
                    
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
	            	
	            }
	            
		 }
		 
	}
	

}
