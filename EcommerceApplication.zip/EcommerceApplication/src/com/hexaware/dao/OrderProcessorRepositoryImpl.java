package com.hexaware.dao;
import java.sql.Connection;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import com.hexaware.util.DBConnection;
import com.hexaware.entity.*;
import com.hexaware.exception.CustomerNotFoundException;
import com.hexaware.exception.ProductNotFoundException;

public class OrderProcessorRepositoryImpl implements IOrderProcessorRepository{
	
	static Connection connection;
	
	public OrderProcessorRepositoryImpl() {
//		connection = DBConn.getDBConn();
		connection=DBConnection.getConnection();
	}
	
	@Override
	public boolean createProduct(Products product) {
			Boolean var=false;
            String sql = "INSERT INTO 	PRODUCTS(PRODUCT_ID,PRODUCT_NAME,PRODUCT_PRICE,PRODUCT_DESCRIPTION,STOCK_QUANTITY) VALUES (?, ?, ?, ?, ?)";
            try {
            	PreparedStatement statement = connection.prepareStatement(sql);
                statement.setInt(1, product.getProductId());
                statement.setString(2, product.getpName());
                statement.setDouble(3, product.getPrice());
                statement.setString(4, product.getDescription());
                statement.setInt(5, product.getStockQuantity());
                
                int noOfRows=statement.executeUpdate();
                System.out.println(noOfRows+" rows inserted in Product Table");
                var=true;
            }
        catch(SQLException e) {
            e.printStackTrace();  
        }
        return var;
    }
	
	public boolean createCustomer(Customers customer) {
			boolean var=false;
            String sql = "INSERT INTO CUSTOMERS(CUSTOMER_ID,NAME,EMAIL,C_PASSWORD) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, customer.getCustomerId());
                statement.setString(2, customer.getName());
                statement.setString(3, customer.getEmail());
                statement.setString(4, customer.getPassword());
                int noOfRows=statement.executeUpdate();
                System.out.println(noOfRows+" rows inserted in Product Table");
                var=true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
            return var;
	}
	
	@Override
    public boolean deleteProduct(int productId) throws SQLException, ProductNotFoundException {
            // Delete orders related to the product
            // Now, delete the product
            String sql = "DELETE FROM PRODUCTS WHERE PRODUCT_ID = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, productId);
                int rowsDeleted = statement.executeUpdate();
                
                if (rowsDeleted > 0) {
                    System.out.println("Product deleted successfully.");
                    return true;
                } 
                    else {
                    throw new ProductNotFoundException();
                }
            }
            catch (SQLException e) {
                e.printStackTrace();
            }
            return false;
    }

    public boolean deleteCustomer(int customerId) throws SQLException, CustomerNotFoundException {
    	
    		String sql="DELETE FROM CUSTOMERS WHERE CUSTOMER_ID=?";
    		try(PreparedStatement statement=connection.prepareStatement(sql)){
    			statement.setInt(1,customerId);
    			int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Product deleted successfully.");
                    return true;
                } else {
                	throw new CustomerNotFoundException();
                   
                }
    		}
    		
    }
    
    public boolean addToCart(Cart cart,Customers customer, Products product, int quantity) {
    	
    		boolean var=false;
    		String sql="INSERT INTO CART VALUES(?,?,?,?)";
    		try(PreparedStatement statement=connection.prepareStatement(sql)){
    			statement.setInt(1, cart.getCartId());
    			statement.setInt(2, customer.getCustomerId());
    			statement.setInt(3, product.getProductId());
    			statement.setInt(4, cart.getQuantity());
    			 int noOfRows=statement.executeUpdate();
                 System.out.println(noOfRows+" rows inserted in Product Table");
    			var=true;
    		}
    	catch(SQLException e) {
    		e.printStackTrace();
    	
    	}
    		return var;
    }
    public boolean removeFromCart(Customers customer, Products product) {
    	String sql="DELETE FROM CART WHERE CUSTOMER_ID=? AND PRODUCT_ID=?";
  
		try(PreparedStatement statement=connection.prepareStatement(sql)){
			statement.setInt(1, customer.getCustomerId());
			statement.setInt(2, product.getProductId());
			int rowsDeleted = statement.executeUpdate();
			if (rowsDeleted > 0) {
                System.out.println("Cart Removed successfully.");
                return true;
            } else {
                System.out.println("Product and Customer not found");
                return false;
            }
		}
	catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
    	
    }	
    public List<Products> getAllFromCart(Customers customer){
    	List<Products> cartProducts = new ArrayList<>();
    	
    	try {
    		PreparedStatement statement=connection.prepareStatement("SELECT * FROM PRODUCTS WHERE PRODUCT_ID IN (SELECT PRODUCT_ID FROM CART WHERE CUSTOMER_ID=?)");
    		statement.setInt(1, customer.getCustomerId());
    		ResultSet rs=statement.executeQuery();
    		
    		while(rs.next()) {
    			Products p=new Products();
    			p.setProductId(rs.getInt("PRODUCT_ID"));
    			p.setpName(rs.getString("PRODUCT_NAME"));
    			p.setPrice(rs.getDouble("PRODUCT_PRICE"));
				p.setDescription(rs.getString("PRODUCT_DESCRIPTION"));
				p.setStockQuantity(rs.getInt("STOCK_QUANTITY"));
				cartProducts.add(p);
    			
    		}
    	}
    	catch(SQLException e) {
    		e.printStackTrace();
    	
    	}
		return cartProducts;
    	
    }
    @Override
	public boolean placeOrder(Customers customer,Orders order, List<Map<Products, Integer>> productsAndQuantities) {
		try {
			Random random = new Random();
			PreparedStatement statement = connection.prepareStatement("INSERT INTO ORDERS VALUES(?, ?, ?, ?, ?)");
			statement.setInt(1, order.getOrderId());
			statement.setInt(2, customer.getCustomerId());
			statement.setDate(3, (Date) order.getOrderDate());
			statement.setDouble(4, order.getTotalPrice());
			statement.setString(5, order.getShippingAddress());
			int noofrows = statement.executeUpdate();
			PreparedStatement get_ps = connection.prepareStatement("SELECT* FROM ORDERS WHERE ORDER_ID=?");
			get_ps.setInt(1, order.getOrderId());
			ResultSet rs = get_ps.executeQuery();
			while(rs.next())
			{
				int orderid1 = rs.getInt("ORDER_ID");
		        int orderItemsId = random.nextInt(1000);
		        PreparedStatement statement1 = connection.prepareStatement("insert into order_items values (?, ?, ?, ?)");
		        statement1.setInt(1, orderItemsId);
		        statement1.setInt(2, orderid1);
				for (Map<Products, Integer> productQuantityMap : productsAndQuantities) {
                    for (Map.Entry<Products, Integer> entry : productQuantityMap.entrySet()) {
                        Products product = entry.getKey();
                        int quantity = entry.getValue();
                        statement1.setInt(3, product.getProductId());
                        statement1.setInt(4, quantity);
                    }
                }
				int batchResult = statement1.executeUpdate();
				System.out.println(batchResult + " inserted successfully");
				
				return true;
			}
        } catch (SQLException e) {
        	e.printStackTrace();
        }
		return false;
	}
    
    public List<Map<Products, Integer>> getOrdersByCustomer(int customerId){
		
    	List<Map<Products, Integer>> orderListOfCustomer=new ArrayList<>();
    	try {
    		PreparedStatement statement=connection.prepareStatement("SELECT O.ORDER_ID,O.TOTAL_PRICE,O.SHIPPING_ADDRESS,OI.PRODUCT_ID,OI.QUANTITY FROM ORDERS O JOIN ORDER_ITEMS OI ON O.ORDER_ID=OI.ORDER_ID WHERE O.CUSTOMER_ID=?");
    		statement.setInt(1, customerId);
    		ResultSet rs=statement.executeQuery();
    		while(rs.next()) {
    			int productId=rs.getInt("PRODUCT_ID");
    			int quantity=rs.getInt("QUANTITY");
    			
    			 Products product = getProductById(productId);
                 Map<Products, Integer> orderDetails = new HashMap<>();
                 orderDetails.put(product, quantity);

                 orderListOfCustomer.add(orderDetails);
    			
    		}
    	}
    	catch (SQLException e)
		{
			e.printStackTrace();
		}
		
		return orderListOfCustomer;
    }
    
    private Products getProductById(int productId) {
		// TODO Auto-generated method stub
		Products p = new Products();
		try {
			
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM PRODUCTS WHERE PRODUCT_ID=?");
			statement.setInt(1, productId);
			
			ResultSet rs = statement.executeQuery();
			while(rs.next())
			{
				p.setProductId(rs.getInt("PRODUCT_ID"));
				p.setpName(rs.getString("PRODUCT_NAME"));
				p.setPrice(rs.getDouble("PRODUCT_PRICE"));
				p.setDescription(rs.getString("PRODUCT_DESCRIPTION"));
				p.setStockQuantity(rs.getInt("STOCK_QUANTITY"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return p;
	}
}
    

