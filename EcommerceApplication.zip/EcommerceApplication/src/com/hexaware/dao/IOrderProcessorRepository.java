package com.hexaware.dao;
import com.hexaware.entity.*;
import com.hexaware.exception.CustomerNotFoundException;
import com.hexaware.exception.ProductNotFoundException;

import java.sql.SQLException;
import java.util.*;
public interface IOrderProcessorRepository {
	
	boolean createProduct(Products product);
	boolean createCustomer(Customers customer);
	boolean deleteProduct(int ptoductId) throws SQLException,ProductNotFoundException;
	boolean deleteCustomer(int customerId) throws SQLException, CustomerNotFoundException;
	boolean addToCart(Cart cart, Customers customer, Products product, int quantity);
	boolean removeFromCart(Customers customer, Products product);	
	List<Products> getAllFromCart(Customers customer);
	boolean placeOrder(Customers customer,Orders order, List<Map<Products, Integer>> prodandquant );
	List<Map<Products, Integer>> getOrdersByCustomer(int customerId);
}
