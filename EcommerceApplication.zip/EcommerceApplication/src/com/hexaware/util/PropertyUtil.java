package com.hexaware.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class PropertyUtil {
static Connection connection;

public static Connection getPropertyString() throws IOException, SQLException, ClassNotFoundException{
	FileInputStream file=new FileInputStream("C:\\Users\\DELL\\eclipse-workspace\\EcommerceApplication\\src\\db.properties");
	Properties properties=new Properties();
	properties.load(file);
	String uname=properties.getProperty("jdbc.username");
	String password=properties.getProperty("jdbc.password");
	String drivername=properties.getProperty("jdbc.driver");
	String url=properties.getProperty("jdbc.url");
	
	//load driver
	Class.forName(drivername);
	System.out.println("Driver Loaded");
	//getting connection
	connection=DriverManager.getConnection(url, uname, password);
	System.out.println("Connection Established");
	return connection;
}


}

