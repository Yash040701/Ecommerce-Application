package com.hexaware.entity;

public class Cart {
	private int cartId;
	private Customers customer;
	private Products product;
	private int quantity;
	
	public Cart() {
		
	}
	public Cart(int cartId,Customers customer,Products product,int quantity) {
		super();
		this.cartId=cartId;
		this.customer=customer;
		this.product=product;
		this.quantity=quantity;
		
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	
	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	public Products getProduct() {
		return product;
	}
	public void setProduct(Products product) {
		this.product = product;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
