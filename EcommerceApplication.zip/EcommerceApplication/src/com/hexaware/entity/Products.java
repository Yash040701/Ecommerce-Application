package com.hexaware.entity;

import java.util.Scanner;

public class Products {
	private int productId;
	private String pName;
	private double price;
	private int stockQuantity;
	private String description;

	
	public Products() {
		
	}
	public Products(int productId,String pName,double price,String description,int stockQuantity) {
		
		this.productId=productId;
		this.pName=pName;
		this.price=price;
		this.stockQuantity=stockQuantity;
		this.description=description;
		
	}
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + pName + ", price=" + price + ", description="
				+ description + ", stockQuantity=" + stockQuantity + "]";
	}
	
	
}

