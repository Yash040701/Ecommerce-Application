package com.hexaware.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.*;
import org.junit.jupiter.api.Test;

public class JnuitDemo {
	static Customers c;
	@BeforeAll
	public static void beforeEachTest() {
		//create object before executing test cases
		c=new Customers();
		System.out.println("Object Created");
	}
	
	@Test
	public void testMethod() {
		
		int cid=c.getCustomerId();
		assertEquals(c.getCustomerId(),cid);
		System.out.println(cid);
	}
	
	@AfterEach
	public  void afterEachTest() {
		c=null; // to nullify the custructor
	}
}
