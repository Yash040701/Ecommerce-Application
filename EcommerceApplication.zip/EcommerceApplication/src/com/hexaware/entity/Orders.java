package com.hexaware.entity;
import java.util.*;
//import java.sql.Date;

public class Orders {
	private int orderId;
	private Customers customer;
	private Date orderDate;
	private double totalPrice;
	private String shippingAddress;
	
	public Orders() {
		
	}

	public Orders(int orderId,Customers customer,Date orderDate,double totalPrice,String shippingAddress) {
		this.orderId=orderId;
		this.customer=customer;
		this.orderDate=orderDate;
		this.totalPrice=totalPrice;
		this.shippingAddress=shippingAddress;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	
	@Override
	public String toString() {
		return "Orders[ Order ID: "+orderId+" Customers: "+customer+" Order Date: "+orderDate+"Toal Price: "+totalPrice+" Shipping Address: "+shippingAddress+" ]";
	}
	
}
