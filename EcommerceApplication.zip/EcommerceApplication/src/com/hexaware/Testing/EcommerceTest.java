package com.hexaware.Testing;
import java.sql.SQLException;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import com.hexaware.dao.IOrderProcessorRepository;
import com.hexaware.dao.OrderProcessorRepositoryImpl;
import com.hexaware.entity.*;
import com.hexaware.exception.CustomerNotFoundException;
import com.hexaware.exception.ProductNotFoundException;
class EcommerceTest {
	
	static IOrderProcessorRepository opr;
	Random random = new Random();
	int id = random.nextInt(1000);
	
//    @BeforeEach
//    public void removeData() throws SQLException, ProductNotFoundException {
//        opr.deleteProduct(id);
//    }
	@BeforeAll
	public static void onjcreation() {
		opr=new OrderProcessorRepositoryImpl();
	}
	
	@Test
	public void testProduct() {
		
		Products product = new Products(id, "Phone", 12.3, "Iphone13", 10);
        boolean isDone = opr.createProduct(product);
        assertTrue(isDone);
	}
	
	@Test
	public void testCart() {
		
		Cart cart=new Cart();
		Customers customer = new Customers();
        customer.setCustomerId(11);
        Products product = new Products(11, "book", 12.3, "A book", 10);

        
        cart.setCartId(10);
        boolean isDone = opr.addToCart(cart, customer, product, 13);

        assertTrue(isDone);
        
	}
	
	@Test
	public void testException() throws SQLException, ProductNotFoundException {
		
		 try {
	            opr.deleteProduct(15);
	            // If the above line does not throw ProductNotFoundException, fail the test
	            assert false : "Expected ProductNotFoundException, but no exception was thrown";
	        } catch (ProductNotFoundException p) {
	            // The exception is expected, the test will pass
	        	System.out.println("Product Not Found");
	        }
	}

}
