package com.hexaware.extraMethods;
import com.hexaware.entity.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PandQ {
	
	public static List<Map<Products, Integer>> getProductsAndQuantities(List<Products> cartProducts) {
		List<Map<Products, Integer>> productsAndQuantities = new ArrayList<>();

        for (Products product : cartProducts) {
            Map<Products, Integer> productQuantityMap = new HashMap<>();
            productQuantityMap.put(product, 1); // Assuming quantity is 1 for each product in the cart
            productsAndQuantities.add(productQuantityMap);
        }

        return productsAndQuantities;
	}
}


