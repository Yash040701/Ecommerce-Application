package com.hexaware.exception;

public class ProductNotFoundException extends Exception{
	public ProductNotFoundException() {
		System.out.println("From Product not found exception");
	}

}